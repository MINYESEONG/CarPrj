#pragma once
#include <string>
using namespace std;
class Car
{
private:
	int speed;
	int gear;
	string color;

public:
	Car();
	~Car();
};