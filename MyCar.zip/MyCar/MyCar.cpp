// MyCar.cpp : 콘솔 응용 프로그램에 대한 진입점을 정의합니다.
//

#include "stdafx.h"
//#include "Car.h"

int main()
{
	Car c1;
		
    return 0;
}

